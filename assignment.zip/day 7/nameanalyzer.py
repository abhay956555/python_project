name = input("Enter name student:")

print("upper:" , name.upper())
print("lower:" , name.lower())
print("Length:", len(name))
print("first character:", name.upper[0])
print("last character:", name.lower[1])
